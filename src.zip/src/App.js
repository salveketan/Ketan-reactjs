import './App.css';
import AllRoutes from './components/Routes';

function App() {
  return (
    <div >
      <AllRoutes />
    </div>
  );
}

export default App;
